#ifndef modelH
#define modelH
#include "usertype.h"
#include "uIncludes.h"

void _TK12J02_M();
void _RA11S04_M();
void _RL51S03_M();
void _TH12S15_M();
void _TH12S18_M();
void _TP60S07_M();
void _model();

#endif
