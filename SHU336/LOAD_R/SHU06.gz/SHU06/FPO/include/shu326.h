#ifndef shu326H
#define shu326H
#include "usertype.h"
#include "uIncludes.h"

void _MNMRI();
void _KPIM();
void _FILTR();
void _LVR_LFU_TK12();
void _VR_TK12J02();
smallint _SUMMA(const smallint IN1, const smallint IN2);
void _ZR_TK12J02();
void _TK12J02REG();
void _LVR_LFU_RA11();
void _BLOK_RA11();
smallint _Multiple(const smallint IN1, const smallint IN2);
void _ZR_RA11S04();
void _RA11C04();
void _LVR_LFU_RL51();
void _BLOK_RL51();
void _ZR_RL51S03();
void _RL51C03();
void _OCHK();
void _MNMRO();
void _VIZOV();
void _shu326();

#endif
