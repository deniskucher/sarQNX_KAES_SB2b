#ifndef KDH
#define KDH
#include "KD_Classes.h"
  extern bool _TK12J02F_1; // to reserve MK
  extern bool _RA11S04F_1; // to reserve MK
  extern bool _RL51S03F_1; // to reserve MK
  extern bool _Y066B20F_1; // to reserve MK
  extern bool _T072B03F_1; // to reserve MK
  extern bool _T117B03F_1; // to reserve MK
  extern bool _T117B02F_1; // to reserve MK
  extern bool _D14MC1_79F_1; // to reserve MK
  extern bool _D14MC1_85F_1; // to reserve MK
  extern bool _TH12S15F_1; // to reserve MK
  extern bool _TH12S18F_1; // to reserve MK
  extern bool _TP60S07F_1; // to reserve MK
  extern bool _YA11T766F_1; // to reserve MK
  extern bool _YA11T778F_1; // to reserve MK
  extern bool _TH12T152F_1; // to reserve MK
  extern bool _T653P01F_1; // to reserve MK
  const short KOL_AI1=16;
  const short KOL_AI2=(2/2);
  const short KOL_AI3=(0/3);
  extern void KD_RUN(); 
  extern void Init_KD();
#endif
