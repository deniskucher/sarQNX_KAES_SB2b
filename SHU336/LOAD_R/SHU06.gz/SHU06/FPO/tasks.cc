#include "tasks.h"
#include "shu336.h"

void _TaskFPO()
{
  _shu336();
}

