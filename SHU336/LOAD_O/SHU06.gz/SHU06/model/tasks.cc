#include "tasks.h"
#include "model.h"

void _TaskMod()
{
  _model();
}

