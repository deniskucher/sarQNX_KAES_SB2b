#include "uobjects.h"
#include "globals.h"
#include "model.h"

void _TK12J02_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TK12M_MRI->_MR_MRI(_TK12J02MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TK12_MR->_MR_009(_TK12J02B02,_TK12J02B01,_TK12J02SA2,_TK12J02SA1,false,false,_TK12J02SAC,_TK12J02SAD,
    _TK12J02SA1R,_TK12J02SA2R,_TK12J02RHU,_TK12J02BHU,_TK12J02SA3,_TK12J02SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TK12M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TK12J02MRI = _0LBDMRO;
}

void _RA11S04_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _RA11M_MRI->_MR_MRI(_RA11S04MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _RA11_MR->_MR_009(_RA11S04B02,_RA11S04B01,_RA11S04SA2,_RA11S04SA1,false,false,_RA11S04SAC,_RA11S04SAD,
    _RA11S04SA1R,_RA11S04SA2R,_RA11S04RHU,_RA11S04BHU,_RA11S04SA3,_RA11S04SA4,_RA11S04KBR,_RA11S04B06,_2ZBPR,
    _2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,true,false,33,21,_1A03,_1A04,_1TZOVU,
    _1TZZVU,_1SA1VU,_1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _RA11M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _RA11S04MRI = _0LBDMRO;
}

void _RL51S03_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _RL51M_MRI->_MR_MRI(_RL51S03MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _RL51_MR->_MR_009(_RL51S03B02,_RL51S03B01,_RL51S03SA2,_RL51S03SA1,false,false,_RL51S03SAC,_RL51S03SAD,
    _RL51S03SA1R,_RL51S03SA2R,_RL51S03RHU,_RL51S03BHU,_RL51S03SA3,_RL51S03SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _RL51M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _RL51S03MRI = _0LBDMRO;
}

void _TH12S15_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TH15M_MRI->_MR_MRI(_TH12S15MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TH15_MR->_MR_009(_TH12S15B02,_TH12S15B01,_TH12S15SA2,_TH12S15SA1,false,false,_TH12S15SAC,_TH12S15SAD,
    _TH12S15SA1R,_TH12S15SA2R,_TH12S15RHU,_TH12S15BHU,_TH12S15SA3,_TH12S15SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TH15M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TH12S15MRI = _0LBDMRO;
}

void _TH12S18_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TH18M_MRI->_MR_MRI(_TH12S18MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TH18_MR->_MR_009(_TH12S18B02,_TH12S18B01,_TH12S18SA2,_TH12S18SA1,false,false,_TH12S18SAC,_TH12S18SAD,
    _TH12S18SA1R,_TH12S18SA2R,_TH12S18RHU,_TH12S18BHU,_TH12S18SA3,_TH12S18SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TH18M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TH12S18MRI = _0LBDMRO;
}

void _TP60S07_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TP60M_MRI->_MR_MRI(_TP60S07MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TP60_MR->_MR_009(_TP60S07B02,_TP60S07B01,_TP60S07SA2,_TP60S07SA1,false,false,_TP60S07SAC,_TP60S07SAD,
    _TP60S07SA1R,_TP60S07SA2R,_TP60S07RHU,_TP60S07BHU,_TP60S07SA3,_TP60S07SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,true,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TP60M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TP60S07MRI = _0LBDMRO;
}

void _model()
{

  _TK12J02_M();
  _RA11S04_M();
  _RL51S03_M();
  _TH12S15_M();
  _TH12S18_M();
  _TP60S07_M();
}

