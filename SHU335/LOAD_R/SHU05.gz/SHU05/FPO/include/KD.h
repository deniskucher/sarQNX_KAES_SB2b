#ifndef KDH
#define KDH
#include "KD_Classes.h"
  extern bool _TH11S15F_1; // to reserve MK
  extern bool _TH11S18F_1; // to reserve MK
  extern bool _TK11J02F_1; // to reserve MK
  extern bool _RA13S04F_1; // to reserve MK
  extern bool _RA14S04F_1; // to reserve MK
  extern bool _RL53S03F_1; // to reserve MK
  extern bool _RL54S03F_1; // to reserve MK
  extern bool _Y065B20F_1; // to reserve MK
  extern bool _T071B03F_1; // to reserve MK
  extern bool _T116B03F_1; // to reserve MK
  extern bool _T116B02F_1; // to reserve MK
  extern bool _D14MC3_79F_1; // to reserve MK
  extern bool _D14MC4_79F_1; // to reserve MK
  extern bool _D14MC3_84F_1; // to reserve MK
  extern bool _D14MC4_84F_1; // to reserve MK
  extern bool _YA13T768F_1; // to reserve MK
  extern bool _TH11T153F_1; // to reserve MK
  extern bool _YA13T780F_1; // to reserve MK
  const short KOL_AI1=18;
  const short KOL_AI2=(2/2);
  const short KOL_AI3=(0/3);
  extern void KD_RUN(); 
  extern void Init_KD();
#endif
