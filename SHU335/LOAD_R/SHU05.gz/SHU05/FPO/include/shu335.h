#ifndef shu335H
#define shu335H
#include "usertype.h"
#include "uIncludes.h"

void _MNMRI();
void _KPIM();
void _FILTR();
void _KD();
void _LVR_LFU_TH11();
void _POSLED_UPR();
void _ZR_TH11();
void _TH11C15_C18();
void _LVR_LFU_TK11();
void _VR_TK11J02();
void _ZR_TK11J02();
void _TK11J02REG();
void _LVR_LFU_RA13();
void _BLOK_RA13();
smallint _Multiple(const smallint IN1, const smallint IN2);
void _ZR_RA13S04();
void _RA13C04();
void _LVR_LFU_RA14();
void _BLOK_RA14();
void _ZR_RA14S04();
void _RA14C04();
void _LVR_LFU_RL53();
void _BLOK_RL53();
void _ZR_RL53();
void _RL53C03();
void _LVR_LFU_RL54();
void _BLOK_RL54();
void _ZR_RL54();
void _RL54C03();
void _OCHK();
void _MNMRO();
void _VIZOV();
void _shu335();

#endif
