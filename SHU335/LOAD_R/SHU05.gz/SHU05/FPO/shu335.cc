#include "uobjects.h"
#include "globals.h"
#include "shu335.h"

void _MNMRI()
{
  bool _0SO_SR1 = false;
  bool _0SZ_SG1 = false;
  bool _0A03_A01 = false;
  bool _0A04_A02 = false;
  bool _0VH1VU = false;
  bool _0VH2VU = false;
  bool _0DUPRVU = false;
  bool _0DUUBVU = false;
  bool _0BRAKMR = false;
  bool _0VUH1D = false;
  bool _0VUH2D = false;
  bool _0REZ1_SR = false;
  bool _0REZ2_SG = false;
  bool _0SADF = false;
  bool _0SA1F = false;
  bool _0SA2F = false;
  bool _1SO_SR1 = false;
  bool _1SZ_SG1 = false;
  bool _1A03_A01 = false;
  bool _1A04_A02 = false;
  bool _1VH1VU = false;
  bool _1VH2VU = false;
  bool _1DUPRVU = false;
  bool _1DUUBVU = false;
  bool _1BRAKMR = false;
  bool _1VUH1D = false;
  bool _1VUH2D = false;
  bool _1REZ1_SR = false;
  bool _1REZ2_SG = false;
  bool _1SADF = false;
  bool _1SA1F = false;
  bool _1SA2F = false;
  bool _2SO_SR1 = false;
  bool _2SZ_SG1 = false;
  bool _2A03_A01 = false;
  bool _2A04_A02 = false;
  bool _2VH1VU = false;
  bool _2VH2VU = false;
  bool _2DUPRVU = false;
  bool _2DUUBVU = false;
  bool _2BRAKMR = false;
  bool _2VUH1D = false;
  bool _2VUH2D = false;
  bool _2REZ1_SR = false;
  bool _2REZ2_SG = false;
  bool _2SADF = false;
  bool _2SA1F = false;
  bool _2SA2F = false;
  bool _3SO_SR1 = false;
  bool _3SZ_SG1 = false;
  bool _3A03_A01 = false;
  bool _3A04_A02 = false;
  bool _3VH1VU = false;
  bool _3VH2VU = false;
  bool _3DUPRVU = false;
  bool _3DUUBVU = false;
  bool _3BRAKMR = false;
  bool _3VUH1D = false;
  bool _3VUH2D = false;
  bool _3REZ1_SR = false;
  bool _3REZ2_SG = false;
  bool _3SADF = false;
  bool _3SA1F = false;
  bool _3SA2F = false;
  bool _4SO_SR1 = false;
  bool _4SZ_SG1 = false;
  bool _4A03_A01 = false;
  bool _4A04_A02 = false;
  bool _4VH1VU = false;
  bool _4VH2VU = false;
  bool _4DUPRVU = false;
  bool _4DUUBVU = false;
  bool _4BRAKMR = false;
  bool _4VUH1D = false;
  bool _4VUH2D = false;
  bool _4REZ1_SR = false;
  bool _4REZ2_SG = false;
  bool _4SADF = false;
  bool _4SA1F = false;
  bool _4SA2F = false;
  bool _5SO_SR1 = false;
  bool _5SZ_SG1 = false;
  bool _5A03_A01 = false;
  bool _5A04_A02 = false;
  bool _5VH1VU = false;
  bool _5VH2VU = false;
  bool _5DUPRVU = false;
  bool _5DUUBVU = false;
  bool _5BRAKMR = false;
  bool _5VUH1D = false;
  bool _5VUH2D = false;
  bool _5REZ1_SR = false;
  bool _5REZ2_SG = false;
  bool _5SADF = false;
  bool _5SA1F = false;
  bool _5SA2F = false;
  bool _6SO_SR1 = false;
  bool _6SZ_SG1 = false;
  bool _6A03_A01 = false;
  bool _6A04_A02 = false;
  bool _6VH1VU = false;
  bool _6VH2VU = false;
  bool _6DUPRVU = false;
  bool _6DUUBVU = false;
  bool _6BRAKMR = false;
  bool _6VUH1D = false;
  bool _6VUH2D = false;
  bool _6REZ1_SR = false;
  bool _6REZ2_SG = false;
  bool _6SADF = false;
  bool _6SA1F = false;
  bool _6SA2F = false;
  bool _7SO_SR1 = false;
  bool _7SZ_SG1 = false;
  bool _7A03_A01 = false;
  bool _7A04_A02 = false;
  bool _7VH1VU = false;
  bool _7VH2VU = false;
  bool _7DUPRVU = false;
  bool _7DUUBVU = false;
  bool _7BRAKMR = false;
  bool _7VUH1D = false;
  bool _7VUH2D = false;
  bool _7REZ1_SR = false;
  bool _7REZ2_SG = false;
  bool _7SADF = false;
  bool _7SA1F = false;
  bool _7SA2F = false;

  _TK11J02_MRI->_MNMRI(_TK11J02MRI,_0SO_SR1,_0SZ_SG1,_0A03_A01,_0A04_A02,_0VH1VU,_0VH2VU,_0DUPRVU,_0DUUBVU,
    _0BRAKMR,_0VUH1D,_0VUH2D,_0REZ1_SR,_0REZ2_SG,_0SADF,_0SA1F,_0SA2F);
  _TK11J02A03 = _0A03_A01;
  _TK11J02A04 = _0A04_A02;
  _TK11J02DUPRVU = _0DUPRVU;
  _TK11J02DUUBVU = _0DUUBVU;
  _TK11J02OTMR = _0BRAKMR;
  _RL53S03_MRI->_MNMRI(_RL53S03MRI,_1SO_SR1,_1SZ_SG1,_1A03_A01,_1A04_A02,_1VH1VU,_1VH2VU,_1DUPRVU,_1DUUBVU,
    _1BRAKMR,_1VUH1D,_1VUH2D,_1REZ1_SR,_1REZ2_SG,_1SADF,_1SA1F,_1SA2F);
  _RL53S03A03 = _1A03_A01;
  _RL53S03A04 = _1A04_A02;
  _RL53S03DUPRVU = _1DUPRVU;
  _RL53S03DUUBVU = _1DUUBVU;
  _RL53S03OTMR = _1BRAKMR;
  _RA13S04_MRI->_MNMRI(_RA13S04MRI,_2SO_SR1,_2SZ_SG1,_2A03_A01,_2A04_A02,_2VH1VU,_2VH2VU,_2DUPRVU,_2DUUBVU,
    _2BRAKMR,_2VUH1D,_2VUH2D,_2REZ1_SR,_2REZ2_SG,_2SADF,_2SA1F,_2SA2F);
  _RA13S04A03 = _2A03_A01;
  _RA13S04A04 = _2A04_A02;
  _RA13S04DUPRVU = _2DUPRVU;
  _RA13S04DUUBVU = _2DUUBVU;
  _RA13S04OTMR = _2BRAKMR;
  _RA13S04SO1 = _2VUH1D;
  _RA13S04SZ1 = _2VUH2D;
  _RA13S04NZTS = _2REZ1_SR;
  _RA13S04SO1TS = _2REZ2_SG;
  _RL54S03_MRI->_MNMRI(_RL54S03MRI,_3SO_SR1,_3SZ_SG1,_3A03_A01,_3A04_A02,_3VH1VU,_3VH2VU,_3DUPRVU,_3DUUBVU,
    _3BRAKMR,_3VUH1D,_3VUH2D,_3REZ1_SR,_3REZ2_SG,_3SADF,_3SA1F,_3SA2F);
  _RL54S03A03 = _3A03_A01;
  _RL54S03A04 = _3A04_A02;
  _RL54S03DUPRVU = _3DUPRVU;
  _RL54S03DUUBVU = _3DUUBVU;
  _RL54S03OTMR = _3BRAKMR;
  _RA14S04_MRI->_MNMRI(_RA14S04MRI,_4SO_SR1,_4SZ_SG1,_4A03_A01,_4A04_A02,_4VH1VU,_4VH2VU,_4DUPRVU,_4DUUBVU,
    _4BRAKMR,_4VUH1D,_4VUH2D,_4REZ1_SR,_4REZ2_SG,_4SADF,_4SA1F,_4SA2F);
  _RA14S04A03 = _4A03_A01;
  _RA14S04A04 = _4A04_A02;
  _RA14S04DUPRVU = _4DUPRVU;
  _RA14S04DUUBVU = _4DUUBVU;
  _RA14S04OTMR = _4BRAKMR;
  _RA14S04SO1 = _4VUH1D;
  _RA14S04SZ1 = _4VUH2D;
  _RA14S04NZTS = _4REZ1_SR;
  _RA14S04SO1TS = _4REZ2_SG;
  _TH11S15_MRI->_MNMRI(_TH11S15MRI,_5SO_SR1,_5SZ_SG1,_5A03_A01,_5A04_A02,_5VH1VU,_5VH2VU,_5DUPRVU,_5DUUBVU,
    _5BRAKMR,_5VUH1D,_5VUH2D,_5REZ1_SR,_5REZ2_SG,_5SADF,_5SA1F,_5SA2F);
  _TH11S15A03 = _5A03_A01;
  _TH11S15A04 = _5A04_A02;
  _TH11S15DUPRVU = _5DUPRVU;
  _TH11S15DUUBVU = _5DUUBVU;
  _TH11S15OTMR = _5BRAKMR;
  _TH11S18_MRI->_MNMRI(_TH11S18MRI,_6SO_SR1,_6SZ_SG1,_6A03_A01,_6A04_A02,_6VH1VU,_6VH2VU,_6DUPRVU,_6DUUBVU,
    _6BRAKMR,_6VUH1D,_6VUH2D,_6REZ1_SR,_6REZ2_SG,_6SADF,_6SA1F,_6SA2F);
  _TH11S18A03 = _6A03_A01;
  _TH11S18A04 = _6A04_A02;
  _TH11S18DUPRVU = _6DUPRVU;
  _TH11S18DUUBVU = _6DUUBVU;
  _TH11S18OTMR = _6BRAKMR;
  _REZERV_MRI->_MNMRI(_REZERVMRI,_7SO_SR1,_7SZ_SG1,_7A03_A01,_7A04_A02,_7VH1VU,_7VH2VU,_7DUPRVU,_7DUUBVU,
    _7BRAKMR,_7VUH1D,_7VUH2D,_7REZ1_SR,_7REZ2_SG,_7SADF,_7SA1F,_7SA2F);
  _REZERVA03 = _7A03_A01;
  _REZERVA04 = _7A04_A02;
}

void _KPIM()
{
  bool _0ZAK = false;
  bool _0OTK = false;
  bool _0NP = false;
  bool _1ZAK = false;
  bool _1OTK = false;
  bool _1NP = false;
  bool _2ZAK = false;
  bool _2OTK = false;
  bool _2NP = false;
  bool _3ZAK = false;
  bool _3OTK = false;
  bool _3NP = false;
  bool _4ZAK = false;
  bool _4OTK = false;
  bool _4NP = false;
  bool _5ZAK = false;
  bool _5OTK = false;
  bool _5NP = false;
  bool _6ZAK = false;
  bool _6OTK = false;
  bool _6NP = false;

  _TK11J02_KPIM->_KPIM(_TK11J02B02,_TK11J02B01,_0ZAK,_0OTK,_0NP);
  _TK11J02ZAK = _0ZAK;
  _TK11J02OTK = _0OTK;
  _TK11J02NP = _0NP;
  _TH11S15_KPIM->_KPIM(_TH11S15B02,_TH11S15B01,_1ZAK,_1OTK,_1NP);
  _TH11S15ZAK = _1ZAK;
  _TH11S15OTK = _1OTK;
  _TH11S15NP = _1NP;
  _RL53S03_KPIM->_KPIM(_RL53S03B02,_RL53S03B01,_2ZAK,_2OTK,_2NP);
  _RL53S03ZAK = _2ZAK;
  _RL53S03OTK = _2OTK;
  _RL53S03NP = _2NP;
  _TH11S18_KPIM->_KPIM(_TH11S18B02,_TH11S18B01,_3ZAK,_3OTK,_3NP);
  _TH11S18ZAK = _3ZAK;
  _TH11S18OTK = _3OTK;
  _TH11S18NP = _3NP;
  _RL54S03_KPIM->_KPIM(_RL54S03B02,_RL54S03B01,_4ZAK,_4OTK,_4NP);
  _RL54S03ZAK = _4ZAK;
  _RL54S03OTK = _4OTK;
  _RL54S03NP = _4NP;
  _RA13S04_KPIM->_KPIM(_RA13S04B02,_RA13S04B01,_5ZAK,_5OTK,_5NP);
  _RA13S04ZAK = _5ZAK;
  _RA13S04OTK = _5OTK;
  _RA13S04NP = _5NP;
  _RA14S04_KPIM->_KPIM(_RA14S04B02,_RA14S04B01,_6ZAK,_6OTK,_6NP);
  _RA14S04ZAK = _6ZAK;
  _RA14S04OTK = _6OTK;
  _RA14S04NP = _6NP;
}

void _FILTR()
{
  smallint _0D = 0;
  smallint _1D = 0;
  smallint _2D = 0;
  smallint _3D = 0;
  smallint _4D = 0;
  smallint _5D = 0;
  smallint _6D = 0;
  smallint _7D = 0;
  smallint _8D = 0;
  smallint _9D = 0;
  smallint _10D = 0;
  smallint _11D = 0;
  smallint _12D = 0;
  smallint _13D = 0;
  smallint _14D = 0;
  smallint _15D = 0;
  smallint _16D = 0;

  _0D = _TK11J02_AF->_AF(_TK11J02SBRN,_TK11J02R,_TK11J02TF,_TK11J02AMX);
  _TK11J02D = _0D;
  _1D = _Y065B20_AF->_AF(_Y065B20SBRN,_Y065B20R,_Y065B20TF,_Y065B20AMX);
  _Y065B20D = _1D;
  _2D = _RL53S03_AF->_AF(_RL53S03SBRN,_RL53S03R,_RL53S03TF,_RL53S03AMX);
  _RL53S03D = _2D;
  _3D = _T116B0_AF->_AF(_T116B0SBRN,_T116B0R,_T116B0TF,_T116B0AMX);
  _T116B0D = _3D;
  _4D = _RL54S03_AF->_AF(_RL54S03SBRN,_RL54S03R,_RL54S03TF,_RL54S03AMX);
  _RL54S03D = _4D;
  _5D = _T071B03_AF->_AF(_T071B03SBRN,_T071B03R,_T071B03TF,_T071B03AMX);
  _T071B03D = _5D;
  _6D = _RA13S04_AF->_AF(_RA13S04SBRN,_RA13S04R,_RA13S04TF,_RA13S04AMX);
  _RA13S04D = _6D;
  _7D = _D14MC3_76_AF->_AF(_D14MC3_84SBRN,_D14MC3_84R,_D14MC3_84TF,_D14MC3_84AMX);
  _D14MC3_84D = _7D;
  _8D = _RA14S04_AF->_AF(_RA14S04SBRN,_RA14S04R,_RA14S04TF,_RA14S04AMX);
  _RA14S04D = _8D;
  _9D = _D14MC4_76_AF->_AF(_D14MC4_84SBRN,_D14MC4_84R,_D14MC4_84TF,_D14MC4_84AMX);
  _D14MC4_84D = _9D;
  _10D = _TH11S15_AF->_AF(_TH11S15SBRN,_TH11S15R,_TH11S15TF,_TH11S15AMX);
  _TH11S15D = _10D;
  _11D = _D14MC3_79_AF->_AF(_D14MC3_79SBRN,_D14MC3_79R,_D14MC3_79TF,_D14MC3_79AMX);
  _D14MC3_79D = _11D;
  _12D = _TH11S18_AF->_AF(_TH11S18SBRN,_TH11S18R,_TH11S18TF,_TH11S18AMX);
  _TH11S18D = _12D;
  _13D = _D14MC4_79_AF->_AF(_D14MC4_79SBRN,_D14MC4_79R,_D14MC4_79TF,_D14MC4_79AMX);
  _D14MC4_79D = _13D;
  _14D = _TH11T156_AF->_AF(_TH11T153SBRN,_TH11T153R,_TH11T153TF,_TH11T153AMX);
  _TH11T153D = _14D;
  _15D = _YA13T768_AF->_AF(_YA13T768SBRN,_YA13T768R,_YA13T768TF,_YA13T768AMX);
  _YA13T768D = _15D;
  _16D = _YA13T780_AF->_AF(_YA13T780SBRN,_YA13T780R,_YA13T780TF,_YA13T780AMX);
  _YA13T780D = _16D;
}

void _KD()
{
  bool _7_R = false;
  bool _9_R = false;
  bool _8_R = false;
  bool _0Out = false;
  bool _6_R = false;
  bool _11_R = false;
  bool _1Out = false;
  bool _10_R = false;
  bool _13_R = false;
  bool _2Out = false;
  bool _12_R = false;
  bool _15_R = false;
  bool _3Out = false;
  bool _14_R = false;
  bool _17_R = false;
  bool _4Out = false;
  bool _16_R = false;
  bool _19_R = false;
  bool _5Out = false;
  bool _18_R = false;

  _7_R = _TH11S15NP && _TH11S15AVT;
  _9_R = _TH11S18NP && _TH11S18AVT;
  _8_R = _7_R || _9_R;
  _0Out = _TH11_OffD->_OffDelay(_8_R,_TH11NPTV);
  _6_R = _0Out;
  _TH11T153ZDV = _6_R;
  _YA13T768ZMX = _6_R;
  _YA13T768ZDV = _6_R;
  _TH11T153ZMN = _6_R;
  _TH11T153ZMX = _6_R;
  _YA13T780ZDV = _6_R;
  _YA13T768ZMN = _6_R;
  _YA13T780ZMN = _6_R;
  _YA13T780ZMX = _6_R;
  _11_R = _TK11J02NP && _TK11J02AVT;
  _1Out = _TK11_OffD->_OffDelay(_11_R,_TK11NPTV);
  _10_R = _1Out;
  _T116B0RZRK = _10_R;
  _T071B03ZMX = _10_R;
  _T071B03ZDV = _10_R;
  _Y065B20ZMN = _10_R;
  _Y065B20ZMX = _10_R;
  _Y065B20ZDV = _10_R;
  _T116B02ZMN = _10_R;
  _T116B02ZMX = _10_R;
  _T116B02ZDV = _10_R;
  _T116B03ZMN = _10_R;
  _T116B03ZMX = _10_R;
  _T116B03ZDV = _10_R;
  _T071B03ZMN = _10_R;
  _13_R = _RA13S04NP && _RA13S04AVT;
  _2Out = _RA13_OffD->_OffDelay(_13_R,_RA13NPTV);
  _12_R = _2Out;
  _D14MC3_79ZDV = _12_R;
  _D14MC3_79ZMX = _12_R;
  _D14MC3_79ZMN = _12_R;
  _15_R = _RA14S04NP && _RA14S04AVT;
  _3Out = _RA14_OffD->_OffDelay(_15_R,_RA14NPTV);
  _14_R = _3Out;
  _D14MC4_79ZDV = _14_R;
  _D14MC4_79ZMX = _14_R;
  _D14MC4_79ZMN = _14_R;
  _17_R = _RL53S03NP && _RL53S03AVT;
  _4Out = _RL53_OffD->_OffDelay(_17_R,_RL53NPTV);
  _16_R = _4Out;
  _D14MC3_84ZDV = _16_R;
  _D14MC3_84ZMX = _16_R;
  _D14MC3_84ZMN = _16_R;
  _19_R = _RL54S03NP && _RL54S03AVT;
  _5Out = _RL54_OffD->_OffDelay(_19_R,_RL54NPTV);
  _18_R = _5Out;
  _D14MC4_84ZDV = _18_R;
  _D14MC4_84ZMX = _18_R;
  _D14MC4_84ZMN = _18_R;
}

void _LVR_LFU_TH11()
{
  bool _0_1 = false;
  bool _0_0 = false;
  bool _10_R = false;
  bool _9_R = false;
  bool _13_R = false;
  bool _11_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _7_R = false;
  bool _8_R = false;
  bool _12_R = false;
  bool _2Out = false;
  bool _14_R = false;
  bool _15_R = false;
  bool _16_R = false;
  bool _3_1 = false;
  bool _3_0 = false;
  bool _4AVT = false;
  bool _4LK = false;
  bool _4LZ = false;
  bool _4ZS = false;
  bool _4NBRU = false;
  bool _17_R = false;
  bool _18_R = false;
  bool _19_R = false;
  bool _5Out = false;
  bool _20_R = false;
  bool _21_R = false;
  bool _22_R = false;
  smallint _6USTO = 0;

  _TH15_str->_STrigger(_TH11S15SAC,_TH11S15SAD,_0_1,_0_0);
  _10_R = _TH11S15NP || _TH11S18NP;
  _9_R =  ! _10_R;
  _13_R = _YA13T768F || _TH11T153F || _YA13T780F;
  _11_R = _9_R && _13_R;
  _TH11S15_LVR->_LVR(_0_1,_0_0,_TH11S15RHU,false,_11_R,_TH11S15NP,_TH11S15RST,_TH11S15REM,_TH11S15TV,_1AVT,
    _1LK,_1LZ,_1ZS,_1NBRU);
  _TH11S15AVT = _1AVT;
  _TH11S15ZS = _1ZS;
  _TH11S15NBRU = _1NBRU;
  _7_R =  ! _TH11S15RHU;
  _8_R = _1LK && _7_R;
  _TH11S15SR = _8_R;
  _12_R = _1LZ && _7_R;
  _TH11S15SG = _12_R;
  _2Out = _TH11_OnD->_OnDelay(_TH11S15NP,_TH11S15TRST);
  _14_R = _2Out && _TH11S15AVT;
  _TH11S15RST = _14_R;
  _15_R =  ! _14_R;
  _16_R = _15_R && _TH11S15AVT;
  _TH11S15RPP = _16_R;
  _TH18->_STrigger(_TH11S18SAC,_TH11S18SAD,_3_1,_3_0);
  _TH11S18_LVR->_LVR(_3_1,_3_0,_TH11S18RHU,false,_11_R,_TH11S18NP,_TH11S18RST,_TH11S18REM,_TH11S18TV,_4AVT,
    _4LK,_4LZ,_4ZS,_4NBRU);
  _TH11S18AVT = _4AVT;
  _TH11S18ZS = _4ZS;
  _TH11S18NBRU = _4NBRU;
  _17_R =  ! _TH11S18RHU;
  _18_R = _4LK && _17_R;
  _TH11S18SR = _18_R;
  _19_R = _4LZ && _17_R;
  _TH11S18SG = _19_R;
  _5Out = _TH11_OnD2->_OnDelay(_TH11S18NP,_TH11S18TRST);
  _20_R = _5Out && _TH11S18AVT;
  _TH11S18RST = _20_R;
  _21_R =  ! _20_R;
  _22_R = _21_R && _TH11S18AVT;
  _TH11S18RPP = _22_R;
  _6USTO = _TH11_LFU->_LFUKN(_TH11UST,_TH11UMN,_TH11UMX,_TH11VUST,_TH11UPRKN,_TH11UUBKN);
  _TH11UST = _6USTO;
  _TH11USTVU = _6USTO;
}

void _POSLED_UPR()
{
  bool _1_R = false;
  bool _5_R = false;
  bool _2_R = false;
  bool _6_R = false;
  bool _0State = false;
  bool _3_R = false;
  bool _15_R = false;
  bool _4_R = false;
  bool _9_R = false;
  bool _7_R = false;
  bool _16_R = false;
  bool _8_R = false;
  bool _12_R = false;
  bool _10_R = false;
  bool _11_R = false;
  bool _13_R = false;
  bool _14_R = false;

  _1_R =  ! _TH11S15OTK;
  _5_R =  ! _TH11S18OTK;
  _2_R = _1_R && _5_R;
  _6_R = _TH11S15OTK && _5_R;
  _0State = _TH11BUT->_ButtonState(_TH11S18PKUKN);
  _TH11S18PKU = _0State;
  _3_R = _2_R || _6_R || _0State;
  _15_R = _TH11S15AVT && _TH11S18AVT;
  _4_R = _3_R && _15_R;
  _TH11S15BLUB = _4_R;
  _9_R = _1_R && _TH11S18OTK;
  _7_R = _2_R || _9_R;
  _16_R =  ! _0State;
  _8_R = _7_R && _15_R && _16_R;
  _TH11S18BLUB = _8_R;
  _12_R = _TH11S15OTK && _TH11S18OTK;
  _10_R = _6_R || _12_R || _0State;
  _11_R = _10_R && _15_R;
  _TH11S15BLPR = _11_R;
  _13_R = _9_R || _12_R;
  _14_R = _13_R && _15_R && _16_R;
  _TH11S18BLPR = _14_R;
}

void _ZR_TH11()
{
  float _9_R = 0.0;
  smallint _4Res = 0;
  float _10_R = 0.0;
  smallint _6Res = 0;
  smallint _5OUT1 = 0;
  float _11_R = 0.0;
  smallint _8Res = 0;
  smallint _7OUT1 = 0;
  smallint _1SM = 0;
  bool _1RM = false;
  bool _1NES = false;
  smallint _1PRK = 0;
  smallint _1S0 = 0;
  smallint _0DHNO = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0ER = 0;
  smallint _3SM = 0;
  bool _3RM = false;
  bool _3NES = false;
  smallint _3PRK = 0;
  smallint _3S0 = 0;
  smallint _2DHNO = 0;
  smallint _2XPR = 0;
  smallint _2CI = 0;
  smallint _2ERZ = 0;
  bool _2OTKR = false;
  bool _2ZAKR = false;
  smallint _2ER = 0;

  _9_R = _YA13T768D * 0.5;
  /*���� ���������*/
  if ((_9_R - floor(_9_R)) > 0.5) _4Res = smallint(ceil(_9_R));
  else _4Res = smallint(floor(_9_R));
  /*End of _Round*/

  _10_R = _YA13T780D * 0.5;
  /*���� ���������*/
  if ((_10_R - floor(_10_R)) > 0.5) _6Res = smallint(ceil(_10_R));
  else _6Res = smallint(floor(_10_R));
  /*End of _Round*/

  _5OUT1 = _SUMMA(_4Res,_6Res);
  _11_R = _TH11T153D * 0.375;
  /*���� ���������*/
  if ((_11_R - floor(_11_R)) > 0.5) _8Res = smallint(ceil(_11_R));
  else _8Res = smallint(floor(_11_R));
  /*End of _Round*/

  _7OUT1 = _RAZN(_5OUT1,_8Res);
  _TH11DT = _7OUT1;
  _TH11S15_MIM->_MIMKD(_TH11S15AVT,_TH11S15R,_TH11S15F,_TH11S15OKD,_TH11S15A03REG,_TH11S15A04REG,_TH11S15NLO,
    _TH11S15NLZ,_TH11S15DP1,_TH11S15DP2,_TH11S15OTK,_TH11S15ZAK,_TH11S15TH,_TH11S15TRK,_TH11S15SBRN,_1SM,_1RM,
    _1NES,_1PRK,_1S0);
  _TH11S15SM = _1SM;
  _TH11S15PRM = _1RM;
  _TH11S15NES = _1NES;
  _TH11S15_AR->_AR(_TH11S15RPP,_TH11USTVU,_7OUT1,true,_TH11S15VPR,_TH11S15DHN,_TH11S15RNR,_TH11S15ZN,
    _TH11S15ZV,_TH11S15EMN,_TH11S15KP,_TH11S15TI1,_TH11S15TI2,_TH11S15BLPR,_TH11S15BLUB,_TH11S15OTK,_TH11S15ZAK,
    _TH11S15ZNZ,_TH11S15ZVZ,_TH11S15NLO,_TH11S15NLZ,0,_1S0,_0DHNO,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0ER);
  _TH11S15DHN = _0DHNO;
  _TH11S15XPR = _0XPR;
  _TH11S15CI = _0CI;
  _TH11S15ERZ = _0ERZ;
  _TH11S15A03REG = _0OTKR;
  _TH11S15A04REG = _0ZAKR;
  _TH11S18_MIM->_MIMKD(_TH11S18AVT,_TH11S18R,_TH11S18F,_TH11S18OKD,_TH11S18A03REG,_TH11S18A04REG,_TH11S18NLO,
    _TH11S18NLZ,_TH11S18DP1,_TH11S18DP2,_TH11S18OTK,_TH11S18ZAK,_TH11S18TH,_TH11S18TRK,_TH11S18SBRN,_3SM,_3RM,
    _3NES,_3PRK,_3S0);
  _TH11S18SM = _3SM;
  _TH11S18PRM = _3RM;
  _TH11S18NES = _3NES;
  _TH11S18_AR->_AR(_TH11S18RPP,_TH11USTVU,_7OUT1,false,_TH11S18VPR,_TH11S18DHN,_TH11S18RNR,_TH11S18ZN,
    _TH11S18ZV,_TH11S18EMN,_TH11S18KP,_TH11S18TI1,_TH11S18TI2,_TH11S18BLPR,_TH11S18BLUB,_TH11S18OTK,_TH11S18ZAK,
    _TH11S18ZNZ,_TH11S18ZVZ,_TH11S18NLO,_TH11S18NLZ,0,_3S0,_2DHNO,_2XPR,_2CI,_2ERZ,_2OTKR,_2ZAKR,_2ER);
  _TH11S18DHN = _2DHNO;
  _TH11S18XPR = _2XPR;
  _TH11S18CI = _2CI;
  _TH11S18ERZ = _2ERZ;
  _TH11S18A03REG = _2OTKR;
  _TH11S18A04REG = _2ZAKR;
}

void _TH11C15_C18()
{

  _LVR_LFU_TH11();
  _POSLED_UPR();
  _ZR_TH11();
}

void _LVR_LFU_TK11()
{
  bool _0_1 = false;
  bool _0_0 = false;
  bool _7_R = false;
  bool _8_R = false;
  bool _10_R = false;
  bool _12_R = false;
  bool _11_R = false;
  bool _9_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _4_R = false;
  bool _5_R = false;
  bool _6_R = false;
  smallint _2USTO = 0;
  smallint _3USTO = 0;

  _TK11_Str->_STrigger(_TK11J02SAC,_TK11J02SAD,_0_1,_0_0);
  _7_R =  ! _TK11J02NP;
  _8_R = _T071B03F || _Y065B20F;
  _10_R = _8_R && _TK11J02PRPP;
  _12_R = _T116B0F && _TK11J02FRPP;
  _11_R = _10_R || _12_R;
  _9_R = _7_R && _11_R;
  _TK11J02_LVR->_LVR(_0_1,_0_0,_TK11J02RHU,false,_9_R,_TK11J02NP,_TK11J02STR,_TK11J02REM,_TK11J02TV,_1AVT,
    _1LK,_1LZ,_1ZS,_1NBRU);
  _TK11J02AVT = _1AVT;
  _TK11J02ZS = _1ZS;
  _TK11J02NBRU = _1NBRU;
  _4_R =  ! _TK11J02RHU;
  _5_R = _1LK && _4_R;
  _TK11J02SR = _5_R;
  _6_R = _1LZ && _4_R;
  _TK11J02SG = _6_R;
  _2USTO = _TK11J02_LFU->_LFUKN(_TK11J02UST,_TK11J02UMN,_TK11J02UMX,_TK11J02VUST,_TK11J02UPRKN,_TK11J02UUBKN);
  _TK11J02UST = _2USTO;
  _TK11J02USTVU = _2USTO;
  _3USTO = _TK11J02_LFUS->_LFUKN(_TK11J02USTS,_TK11J02UMNS,_TK11J02UMXS,_TK11J02VUSTS,_TK11J02UPRKNS,
    _TK11J02UUBKNS);
  _TK11J02USTS = _3USTO;
  _TK11J02USTVUS = _3USTO;
}

void _VR_TK11J02()
{
  bool _6_R = false;
  bool _3_R = false;
  bool _5_R = false;
  bool _4_R = false;
  bool _8_R = false;
  bool _12_R = false;
  bool _14_R = false;
  bool _10_R = false;
  bool _17_R = false;
  bool _11_R = false;
  bool _0_1 = false;
  bool _0_0 = false;
  bool _1Out = false;
  bool _19_R = false;
  bool _18_R = false;
  bool _2Out = false;
  bool _20_R = false;
  bool _13_R = false;
  bool _15_R = false;
  bool _16_R = false;
  bool _9_R = false;
  bool _7_R = false;

  _6_R = _T116B0D > _TKD8VRPPS;
  _TK11J02FB65 = _6_R;
  _3_R =  ! _T116B0F;
  _5_R =  ! _TK11J02TKD8W;
  _4_R = _3_R && _5_R && _6_R;
  _8_R = _T116B0D < _TKD9VRPPS;
  _TK11J02FM60 = _8_R;
  _12_R =  ! _TK11J02TKD9W;
  _14_R =  ! _T116B0F;
  _10_R = _8_R && _12_R && _14_R;
  _17_R =  ! _TK11J02AVT;
  _11_R = _10_R || _TK11J02STR || _17_R;
  _TK11J02_STr->_STrigger(_4_R,_11_R,_0_1,_0_0);
  _1Out = _TK11J02_OnD->_OnDelay(_TK11J02RAB,_TK11J02RABTV);
  _19_R =  ! _TK11J02TKD2W;
  _18_R = _1Out && _19_R && _TK11J02AVT;
  _2Out = _TK11_OnD->_OnDelay(_TK11J02NP,_TK11J02TRST);
  _20_R =  ! _2Out;
  _13_R = _0_1 && _18_R && _20_R;
  _TK11J02FRPP = _13_R;
  _15_R =  ! _13_R;
  _16_R = _15_R && _18_R && _20_R;
  _TK11J02PRPP = _16_R;
  _9_R =  ! _16_R;
  _7_R = _TK11J02AVT && _15_R && _9_R;
  _TK11J02STR = _7_R;
}

void _ZR_TK11J02()
{
  smallint _4OUT1 = 0;
  bool _3B = false;
  smallint _5Res;
  smallint _2SM = 0;
  bool _2RM = false;
  bool _2NES = false;
  smallint _2PRK = 0;
  smallint _2S0 = 0;
  smallint _0XOS = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0DHNO = 0;
  smallint _0ER = 0;
  smallint _1DHNO = 0;
  smallint _1XPR = 0;
  smallint _1CI = 0;
  smallint _1ERZ = 0;
  bool _1OTKR = false;
  bool _1ZAKR = false;
  smallint _1ER = 0;
  bool _6_R = false;
  bool _7_R = false;

  _4OUT1 = _RAZN(_T071B03D,_Y065B20D);
  _TK11J02DP = _4OUT1;
  _3B = _TK11_MH->_MinHyst(_Y065B20D,_TK11KPMN,131);
    _5Res = _3B? _TK11J02KP1 : _TK11J02KP2;
/*  if (_3B) _5Res = _TK11J02KP1;
    
       else _5Res = _TK11J02KP2; */

  _TK11J02_MIM->_MIMKD(_TK11J02AVT,_TK11J02R,_TK11J02F,_TK11J02OKD,_TK11J02A03REG,_TK11J02A04REG,_TK11J02NLO,
    _TK11J02NLZ,_TK11J02DP1,_TK11J02DP2,_TK11J02OTK,_TK11J02ZAK,_TK11J02TH,_TK11J02TRK,_TK11J02SBRN,_2SM,_2RM,
    _2NES,_2PRK,_2S0);
  _TK11J02SM = _2SM;
  _TK11J02PRM = _2RM;
  _TK11J02NES = _2NES;
  _TK11J02_SR->_SR(_TK11J02PRPP,_TK11J02USTVU,_TK11J02D,0,0,_4OUT1,false,false,_TK11J02KOSR,0,0,_TK11J02ZNK,
    _TK11J02TKU,_TK11J02VPR,_TK11J02DHN,_TK11J02RNR,false,true,_TK11J02ZN,_TK11J02ZV,_TK11J02EMN,_5Res,
    _TK11J02TI1,_TK11J02TI2,false,false,_TK11J02OTK,_TK11J02ZAK,_TK11J02ZNZ,_TK11J02ZVZ,_TK11J02NLO,_TK11J02NLZ,
    _TK11J02VKOR,_TK11J02KM,_TK11J02DK,0,_TK11J02SM,_TK11J02PRM,_2S0,_0XOS,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0DHNO,
    _0ER);
  _TK11J02XOS = _0XOS;
  _TK11J02XPR = _0XPR;
  _TK11J02CI = _0CI;
  _TK11J02ERZ = _0ERZ;
  _TK11J02A03_OR = _0OTKR;
  _TK11J02A04_OR = _0ZAKR;
  _TK11J02DHN = _0DHNO;
  _TK11J02_AR->_AR(_TK11J02FRPP,_TK11J02USTVUS,_T116B0D,true,_TK11J02VPRS,_TK11J02DHN,_TK11J02RNR,_TK11J02ZNS,
    _TK11J02ZVS,_TK11J02EMNS,_TK11J02KPS,_TK11J02TI1S,_TK11J02TI2S,false,false,_TK11J02OTK,_TK11J02ZAK,
    _TK11J02ZNZS,_TK11J02ZVZS,_TK11J02NLO,_TK11J02NLZ,0,_2S0,_1DHNO,_1XPR,_1CI,_1ERZ,_1OTKR,_1ZAKR,_1ER);
  _TK11J02DHN = _1DHNO;
  _TK11J02XPRS = _1XPR;
  _TK11J02CIS = _1CI;
  _TK11J02ERZS = _1ERZ;
  _TK11J02A03_SR = _1OTKR;
  _TK11J02A04_SR = _1ZAKR;
  _6_R = _0OTKR || _1OTKR;
  _TK11J02A03REG = _6_R;
  _7_R = _0ZAKR || _1ZAKR;
  _TK11J02A04REG = _7_R;
}

void _TK11J02REG()
{

  _LVR_LFU_TK11();
  _VR_TK11J02();
  _ZR_TK11J02();
}

void _LVR_LFU_RA13()
{
  bool _5_R = false;
  bool _3_R = false;
  bool _0_1 = false;
  bool _0_0 = false;
  bool _8_R = false;
  bool _7_R = false;
  bool _6_R = false;
  bool _11_R = false;
  bool _12_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _4_R = false;
  bool _9_R = false;
  bool _10_R = false;
  smallint _2USTO = 0;

  _5_R =  ! _RA13S04KBR;
  _3_R = _RA13S04NP || _5_R;
  _RA13S04NPTS = _3_R;
  _RA13_Str->_STrigger(_RA13S04SAC,_RA13S04SAD,_0_1,_0_0);
  _8_R =  ! _RA13S04NP;
  _7_R = _5_R && _8_R;
  _6_R = _RA13S04RHU || _7_R;
  _11_R =  ! _RA13S04NP;
  _12_R = _11_R && _D14MC3_79F;
  _RA13_LVR->_LVR(_0_1,_0_0,_6_R,false,_12_R,_RA13S04NP,_RA13S04RST,_RA13S04REM,_RA13S04TV,_1AVT,_1LK,_1LZ,
    _1ZS,_1NBRU);
  _RA13S04AVT = _1AVT;
  _RA13S04ZS = _1ZS;
  _RA13S04NBRU = _1NBRU;
  _4_R =  ! _RA13S04RHU;
  _9_R = _4_R && _1LK;
  _RA13S04SR = _9_R;
  _10_R = _4_R && _1LZ;
  _RA13S04SG = _10_R;
  _2USTO = _RA13_LFU->_LFUKN(_RA13S04UST,_RA13S04UMN,_RA13S04UMX,_RA13S04VUST,_RA13S04UPRKN,_RA13S04UUBKN);
  _RA13S04UST = _2USTO;
  _RA13S04USTVU = _2USTO;
}

void _BLOK_RA13()
{
  bool _0B = false;
  bool _1State = false;
  bool _4_R = false;
  bool _5_R = false;
  bool _3_R = false;
  bool _2B = false;
  bool _7_R = false;
  bool _6_R = false;
  bool _8_R = false;
  bool _12_R = false;
  bool _9_R = false;
  bool _10_R = false;
  bool _11_R = false;

  _0B = _RA13MnH->_MinHyst(_D14MC3_79D,_RA13P67UST,_RA13PGIST);
  _D14MC3PM67 = _0B;
  _1State = _RA13_Butt->_ButtonState(_RA13RASHKN);
  _RA13RASH = _1State;
  _4_R =  ! _RA13RASH;
  _5_R =  ! _D14MC3_79F;
  _3_R = _0B && _4_R && _5_R;
  _RA13PM67ZBZ = _3_R;
  _2B = _RA13MxH2->_MaxHyst(_D14MC3_79D,_RA13PB74UST,_RA13PGIST);
  _D14MC3PB74 = _2B;
  _7_R =  ! _D14MC3_79F;
  _6_R = _2B && _7_R;
  _RA13PB74ZBO = _6_R;
  _8_R =  ! _D14MC3PB74;
  _12_R =  ! _D14MC3PM67;
  _9_R = _8_R && _RA13S04AVT && _12_R;
  _RA13S04RPP = _9_R;
  _10_R =  ! _9_R;
  _11_R = _10_R && _RA13S04AVT;
  _RA13S04RST = _11_R;
}

smallint _Multiple(const smallint IN1, const smallint IN2)
{
    /*���� �������*/
 smallint OUT1 = smallint((float)IN1/32767 * ((float)IN2/32767) * 32767);
 
return OUT1;
}  /*_Multiple*/

void _ZR_RA13S04()
{
  bool _8_R = false;
  smallint _1SM = 0;
  bool _1RM = false;
  bool _1NES = false;
  smallint _1PRK = 0;
  smallint _1S0 = 0;
  smallint _7Res;
  smallint _6OUT1 = 0;
  smallint _5OUT1 = 0;
  bool _2_1 = false;
  bool _2_0 = false;
  bool _9_R = false;
  bool _10_R = false;
  bool _11_R = false;
  bool _14_R = false;
  bool _12_R = false;
  bool _4Out = false;
  bool _15_R = false;
  bool _13_R = false;
  bool _16_R = false;
  bool _17_R = false;
  bool _3_1 = false;
  bool _3_0 = false;
  smallint _0DHNO = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0ER = 0;

  _8_R = _RA13_PROTK || _RA13S04A03REG;
  _RA13_MIM->_MIMKD(_RA13S04AVT,_RA13S04R,_RA13S04F,_RA13S04OKD,_8_R,_RA13S04A04REG,_RA13S04NLO,_RA13S04NLZ,
    _RA13S04DP1,_RA13S04DP2,_RA13S04OTK,_RA13S04ZAK,_RA13S04TH,_RA13S04TRK,_RA13S04SBRN,_1SM,_1RM,_1NES,_1PRK,
    _1S0);
  _RA13S04SM = _1SM;
  _RA13S04PRM = _1RM;
  _RA13S04NES = _1NES;
    _7Res = _1RM? _1SM : _RA13S04D;
/*  if (_1RM) _7Res = _1SM;
    
       else _7Res = _RA13S04D; */

  _6OUT1 = _Multiple(_RA13S04KOSR,_7Res);
  _5OUT1 = _RAZN(_D14MC3_79D,_6OUT1);
  _RA13S04XOS = _5OUT1;
  _RA13OTK_ETr->_ETrigger(_RA13S04RHU,_RA13S04BHU,_2_1,_2_0);
  _9_R = _RA13S04SA1R && _2_1;
  _10_R = _2_0 && _RA13S04SA1;
  _11_R = _9_R || _10_R || _RA13S04A03REG;
  _14_R =  ! _RA13PM67ZBZ;
  _12_R = _11_R && _14_R && _RA13S04B06;
  _4Out = _RA13OT_Sp->_SPulse(_RA13S04RPP,1);
  _15_R = _RA13S04B06 && _4Out;
  _13_R = _12_R || _15_R;
  _16_R =  ! _RA13S04B06;
  _17_R = _16_R || _RA13PM67ZBZ;
  _RA13OTK_Str->_STrigger(_13_R,_17_R,_3_1,_3_0);
  _RA13_PROTK = _3_1;
  _RA13_AR->_AR(_RA13S04RPP,_RA13S04USTVU,_5OUT1,false,_RA13S04VPR,_RA13S04DHN,_RA13S04RNR,_RA13S04ZN,
    _RA13S04ZV,_RA13S04EMN,_RA13S04KP,_RA13S04TI1,_RA13S04TI2,_3_1,_3_1,_RA13S04OTK,_RA13S04ZAK,_RA13S04ZNZ,
    _RA13S04ZVZ,_RA13S04NLO,_RA13S04NLZ,0,_1S0,_0DHNO,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0ER);
  _RA13S04DHN = _0DHNO;
  _RA13S04XPR = _0XPR;
  _RA13S04CI = _0CI;
  _RA13S04ERZ = _0ERZ;
  _RA13S04A03REG = _0OTKR;
  _RA13S04A04REG = _0ZAKR;
}

void _RA13C04()
{

  _LVR_LFU_RA13();
  _BLOK_RA13();
  _ZR_RA13S04();
}

void _LVR_LFU_RA14()
{
  bool _5_R = false;
  bool _3_R = false;
  bool _0_1 = false;
  bool _0_0 = false;
  bool _8_R = false;
  bool _7_R = false;
  bool _6_R = false;
  bool _11_R = false;
  bool _12_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _4_R = false;
  bool _9_R = false;
  bool _10_R = false;
  smallint _2USTO = 0;

  _5_R =  ! _RA14S04KBR;
  _3_R = _RA14S04NP || _5_R;
  _RA14S04NPTS = _3_R;
  _RA14_Str->_STrigger(_RA14S04SAC,_RA14S04SAD,_0_1,_0_0);
  _8_R =  ! _RA14S04NP;
  _7_R = _5_R && _8_R;
  _6_R = _RA14S04RHU || _7_R;
  _11_R =  ! _RA14S04NP;
  _12_R = _11_R && _D14MC4_79F;
  _RA14_LVR->_LVR(_0_1,_0_0,_6_R,false,_12_R,_RA14S04NP,_RA14S04RST,_RA14S04REM,_RA14S04TV,_1AVT,_1LK,_1LZ,
    _1ZS,_1NBRU);
  _RA14S04AVT = _1AVT;
  _RA14S04ZS = _1ZS;
  _RA14S04NBRU = _1NBRU;
  _4_R =  ! _RA14S04RHU;
  _9_R = _1LK && _4_R;
  _RA14S04SR = _9_R;
  _10_R = _1LZ && _4_R;
  _RA14S04SG = _10_R;
  _2USTO = _RA14_LFU->_LFUKN(_RA14S04UST,_RA14S04UMN,_RA14S04UMX,_RA14S04VUST,_RA14S04UPRKN,_RA14S04UUBKN);
  _RA14S04USTVU = _2USTO;
  _RA14S04UST = _2USTO;
}

void _BLOK_RA14()
{
  bool _0B = false;
  bool _1State = false;
  bool _5_R = false;
  bool _6_R = false;
  bool _4_R = false;
  bool _2B = false;
  bool _8_R = false;
  bool _7_R = false;
  bool _9_R = false;
  bool _13_R = false;
  bool _3Out = false;
  bool _14_R = false;
  bool _10_R = false;
  bool _11_R = false;
  bool _12_R = false;

  _0B = _RA14MnH->_MinHyst(_D14MC4_79D,_RA14P67UST,_RA14PGIST);
  _D14MC4PM67 = _0B;
  _1State = _RA14_BSt->_ButtonState(_RA14RASHKN);
  _RA14RASH = _1State;
  _5_R =  ! _RA14RASH;
  _6_R =  ! _D14MC4_79F;
  _4_R = _0B && _5_R && _6_R;
  _RA14PM67ZBZ = _4_R;
  _2B = _RA14MxH2->_MaxHyst(_D14MC4_79D,_RA14PB74UST,_RA14PGIST);
  _D14MC4PB74 = _2B;
  _8_R =  ! _D14MC4_79F;
  _7_R = _2B && _8_R;
  _RA14PB74ZBO = _7_R;
  _9_R =  ! _D14MC4PB74;
  _13_R =  ! _D14MC4PM67;
  _3Out = _RA14_OnD->_OnDelay(_RA14S04NP,_RA14S04TRST);
  _14_R =  ! _3Out;
  _10_R = _9_R && _RA14S04AVT && _13_R && _14_R;
  _RA14S04RPP = _10_R;
  _11_R =  ! _10_R;
  _12_R = _11_R && _RA14S04AVT;
  _RA14S04RST = _12_R;
}

void _ZR_RA14S04()
{
  bool _13_R = false;
  smallint _1SM = 0;
  bool _1RM = false;
  bool _1NES = false;
  smallint _1PRK = 0;
  smallint _1S0 = 0;
  smallint _7Res;
  smallint _6OUT1 = 0;
  smallint _5OUT1 = 0;
  bool _2_1 = false;
  bool _2_0 = false;
  bool _8_R = false;
  bool _9_R = false;
  bool _10_R = false;
  bool _12_R = false;
  bool _11_R = false;
  bool _4Out = false;
  bool _15_R = false;
  bool _14_R = false;
  bool _16_R = false;
  bool _17_R = false;
  bool _3_1 = false;
  bool _3_0 = false;
  smallint _0DHNO = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0ER = 0;

  _13_R = _RA14S04A03REG || _RA14_PROTK;
  _RA14_MIM->_MIMKD(_RA14S04AVT,_RA14S04R,_RA14S04F,_RA14S04OKD,_13_R,_RA14S04A04REG,_RA14S04NLO,_RA14S04NLZ,
    _RA14S04DP1,_RA14S04DP2,_RA14S04OTK,_RA14S04ZAK,_RA14S04TH,_RA14S04TRK,_RA14S04SBRN,_1SM,_1RM,_1NES,_1PRK,
    _1S0);
  _RA14S04SM = _1SM;
  _RA14S04PRM = _1RM;
  _RA14S04NES = _1NES;
    _7Res = _1RM? _1SM : _RA14S04D;
/*  if (_1RM) _7Res = _1SM;
    
       else _7Res = _RA14S04D; */

  _6OUT1 = _Multiple(_RA14S04KOSR,_7Res);
  _5OUT1 = _RAZN(_D14MC4_79D,_6OUT1);
  _RA14S04XOS = _5OUT1;
  _RA14OT_Etr->_ETrigger(_RA14S04RHU,_RA14S04BHU,_2_1,_2_0);
  _8_R = _RA14S04SA1R && _2_1;
  _9_R = _2_0 && _RA14S04SA1;
  _10_R = _8_R || _9_R || _RA14S04A03REG;
  _12_R =  ! _RA14PM67ZBZ;
  _11_R = _10_R && _12_R && _RA14S04B06;
  _4Out = _RA14_Spls->_SPulse(_RA14S04RPP,1);
  _15_R = _RA14S04B06 && _4Out;
  _14_R = _11_R || _15_R;
  _16_R =  ! _RA14S04B06;
  _17_R = _16_R || _RA14PM67ZBZ;
  _RA14_Str1->_STrigger(_14_R,_17_R,_3_1,_3_0);
  _RA14_PROTK = _3_1;
  _RA14_AR->_AR(_RA14S04RPP,_RA14S04USTVU,_5OUT1,false,_RA14S04VPR,_RA14S04DHN,_RA14S04RNR,_RA14S04ZN,
    _RA14S04ZV,_RA14S04EMN,_RA14S04KP,_RA14S04TI1,_RA14S04TI2,_3_1,_3_1,_RA14S04OTK,_RA14S04ZAK,_RA14S04ZNZ,
    _RA14S04ZVZ,_RA14S04NLO,_RA14S04NLZ,0,_1S0,_0DHNO,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0ER);
  _RA14S04DHN = _0DHNO;
  _RA14S04XPR = _0XPR;
  _RA14S04CI = _0CI;
  _RA14S04ERZ = _0ERZ;
  _RA14S04A03REG = _0OTKR;
  _RA14S04A04REG = _0ZAKR;
}

void _RA14C04()
{

  _LVR_LFU_RA14();
  _BLOK_RA14();
  _ZR_RA14S04();
}

void _LVR_LFU_RL53()
{
  bool _0_1 = false;
  bool _0_0 = false;
  bool _4_R = false;
  bool _5_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _7_R = false;
  bool _3_R = false;
  bool _6_R = false;
  smallint _2USTO = 0;

  _RL53_Str1->_STrigger(_RL53S03SAC,_RL53S03SAD,_0_1,_0_0);
  _4_R =  ! _RL53S03NP;
  _5_R = _4_R && _D14MC3_84F;
  _RL53_LVR->_LVR(_0_1,_0_0,_RL53S03RHU,false,_5_R,_RL53S03NP,_RL53S03RST,_RL53S03REM,_RL53S03TV,_1AVT,_1LK,
    _1LZ,_1ZS,_1NBRU);
  _RL53S03AVT = _1AVT;
  _RL53S03ZS = _1ZS;
  _RL53S03NBRU = _1NBRU;
  _7_R =  ! _RL53S03RHU;
  _3_R = _1LK && _7_R;
  _RL53S03SR = _3_R;
  _6_R = _1LZ && _7_R;
  _RL53S03SG = _6_R;
  _2USTO = _RL53_LFU->_LFUKN(_RL53S03UST,_RL53S03UMN,_RL53S03UMX,_RL53S03VUST,_RL53S03UPRKN,_RL53S03UUBKN);
  _RL53S03USTVU = _2USTO;
  _RL53S03UST = _2USTO;
}

void _BLOK_RL53()
{
  bool _6_R = false;
  bool _1Out = false;
  bool _9_R = false;
  bool _5_R = false;
  bool _11_R = false;
  bool _12_R = false;
  bool _13_R = false;
  bool _10_R = false;
  bool _7_R = false;
  bool _0_1 = false;
  bool _0_0 = false;
  bool _4_R = false;
  bool _8_R = false;
  bool _2Out = false;
  bool _14_R = false;
  bool _15_R = false;
  bool _17_R = false;
  bool _16_R = false;
  bool _3_1 = false;
  bool _3_0 = false;

  _6_R =  ! _RL53S03RPPW;
  _1Out = _RL53_OnD->_OnDelay(_RL53S03NP,_RL53S03TRST);
  _9_R =  ! _1Out;
  _5_R = _RL53S03AVT && _6_R && _RL53S03TPNOTKL && _RL53S03PB75 && _9_R;
  _11_R =  ! _RL53S03PB75;
  _12_R =  ! _RL53S03RSTW;
  _13_R = _12_R && _RL53S03TPNVKL && _RL53S03PB75;
  _10_R = _1Out || _11_R || _13_R;
  _7_R = _RL53S03AVT && _10_R;
  _RL53_STr2->_STrigger(_5_R,_7_R,_0_1,_0_0);
  _4_R = _RL53S03AVT && _0_1;
  _RL53S03RPU = _4_R;
  _8_R = _RL53S03AVT && _0_0;
  _RL53S03RST = _8_R;
  _2Out = _RL53_SP->_SPulse(_13_R,2);
  _14_R = _2Out && _RL53S03AVT;
  _15_R =  ! _RL53S03AVT;
  _17_R =  ! _13_R;
  _16_R = _15_R || _17_R;
  _RL53_STr->_STrigger(_14_R,_16_R,_3_1,_3_0);
  _RL53S03BLPR = _3_1;
}

void _ZR_RL53()
{
  smallint _1SM = 0;
  bool _1RM = false;
  bool _1NES = false;
  smallint _1PRK = 0;
  smallint _1S0 = 0;
  smallint _0XOS = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0DHNO = 0;
  smallint _0ER = 0;
  bool _2_R = false;

  _RL53_MIM->_MIMKD(_RL53S03AVT,_RL53S03R,_RL53S03F,_RL53S03OKD,_RL53S03A03REG,_RL53S03A04REG,_RL53S03NLO,
    _RL53S03NLZ,_RL53S03DP1,_RL53S03DP2,_RL53S03OTK,_RL53S03ZAK,_RL53S03TH,_RL53S03TRK,_RL53S03SBRN,_1SM,_1RM,
    _1NES,_1PRK,_1S0);
  _RL53S03SM = _1SM;
  _RL53S03PRM = _1RM;
  _RL53S03NES = _1NES;
  _RL53_SR->_SR(_RL53S03RPU,_RL53S03USTVU,_RL53S03D,0,0,_D14MC3_84D,false,false,_RL53S03KOSR,0,0,_RL53S03ZNK,
    _RL53S03TKU,_RL53S03VPR,_RL53S03DHN,_RL53S03RNR,false,true,_RL53S03ZN,_RL53S03ZV,_RL53S03EMN,_RL53S03KP,
    _RL53S03TI1,_RL53S03TI2,false,false,_RL53S03OTK,_RL53S03ZAK,_RL53S03ZNZ,_RL53S03ZVZ,_RL53S03NLO,_RL53S03NLZ,
    _RL53S03VKOR,_RL53S03KM,_RL53S03DK,0,_RL53S03SM,_RL53S03PRM,_1S0,_0XOS,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0DHNO,
    _0ER);
  _RL53S03XOS = _0XOS;
  _RL53S03XPR = _0XPR;
  _RL53S03CI = _0CI;
  _RL53S03ERZ = _0ERZ;
  _RL53S03A04REG = _0ZAKR;
  _RL53S03DHN = _0DHNO;
  _2_R = _RL53S03BLPR || _0OTKR;
  _RL53S03A03REG = _2_R;
}

void _RL53C03()
{

  _LVR_LFU_RL53();
  _BLOK_RL53();
  _ZR_RL53();
}

void _LVR_LFU_RL54()
{
  bool _0_1 = false;
  bool _0_0 = false;
  bool _6_R = false;
  bool _7_R = false;
  bool _1AVT = false;
  bool _1LK = false;
  bool _1LZ = false;
  bool _1ZS = false;
  bool _1NBRU = false;
  bool _3_R = false;
  bool _4_R = false;
  bool _5_R = false;
  smallint _2USTO = 0;

  _RL54_Str1->_STrigger(_RL54S03SAC,_RL54S03SAD,_0_1,_0_0);
  _6_R =  ! _RL54S03NP;
  _7_R = _6_R && _D14MC4_84F;
  _RL54_LVR->_LVR(_0_1,_0_0,_RL54S03RHU,false,_7_R,_RL54S03NP,_RL54S03RST,_RL54S03REM,_RL54S03TV,_1AVT,_1LK,
    _1LZ,_1ZS,_1NBRU);
  _RL54S03AVT = _1AVT;
  _RL54S03ZS = _1ZS;
  _RL54S03NBRU = _1NBRU;
  _3_R =  ! _RL54S03RHU;
  _4_R = _3_R && _1LK;
  _RL54S03SR = _4_R;
  _5_R = _3_R && _1LZ;
  _RL54S03SG = _5_R;
  _2USTO = _RL54_LFU->_LFUKN(_RL54S03UST,_RL54S03UMN,_RL54S03UMX,_RL54S03VUST,_RL54S03UPRKN,_RL54S03UUBKN);
  _RL54S03USTVU = _2USTO;
  _RL54S03UST = _2USTO;
}

void _BLOK_RL54()
{
  bool _6_R = false;
  bool _1Out = false;
  bool _9_R = false;
  bool _5_R = false;
  bool _11_R = false;
  bool _12_R = false;
  bool _13_R = false;
  bool _10_R = false;
  bool _7_R = false;
  bool _0_1 = false;
  bool _0_0 = false;
  bool _4_R = false;
  bool _8_R = false;
  bool _2Out = false;
  bool _14_R = false;
  bool _15_R = false;
  bool _17_R = false;
  bool _16_R = false;
  bool _3_1 = false;
  bool _3_0 = false;

  _6_R =  ! _RL54S03RPPW;
  _1Out = _RL54_OnD->_OnDelay(_RL54S03NP,_RL54S03TRST);
  _9_R =  ! _1Out;
  _5_R = _RL54S03AVT && _6_R && _RL53S03TPNOTKL && _RL53S03PB75 && _9_R;
  _11_R =  ! _RL53S03PB75;
  _12_R =  ! _RL54S03RSTW;
  _13_R = _12_R && _RL53S03TPNVKL && _RL53S03PB75;
  _10_R = _1Out || _11_R || _13_R;
  _7_R = _RL54S03AVT && _10_R;
  _RL54_STr2->_STrigger(_5_R,_7_R,_0_1,_0_0);
  _4_R = _RL54S03AVT && _0_1;
  _RL54S03RPU = _4_R;
  _8_R = _RL54S03AVT && _0_0;
  _RL54S03RST = _8_R;
  _2Out = _RL54_SP->_SPulse(_13_R,2);
  _14_R = _2Out && _RL54S03AVT;
  _15_R =  ! _RL54S03AVT;
  _17_R =  ! _13_R;
  _16_R = _15_R || _17_R;
  _RL54_STr->_STrigger(_14_R,_16_R,_3_1,_3_0);
  _RL54S03BLPR = _3_1;
}

void _ZR_RL54()
{
  smallint _1SM = 0;
  bool _1RM = false;
  bool _1NES = false;
  smallint _1PRK = 0;
  smallint _1S0 = 0;
  smallint _0XOS = 0;
  smallint _0XPR = 0;
  smallint _0CI = 0;
  smallint _0ERZ = 0;
  bool _0OTKR = false;
  bool _0ZAKR = false;
  smallint _0DHNO = 0;
  smallint _0ER = 0;
  bool _2_R = false;

  _RL54_MIM->_MIMKD(_RL54S03AVT,_RL54S03R,_RL54S03F,_RL54S03OKD,_RL54S03A03REG,_RL54S03A04REG,_RL54S03NLO,
    _RL54S03NLZ,_RL54S03DP1,_RL54S03DP2,_RL54S03OTK,_RL54S03ZAK,_RL54S03TH,_RL54S03TRK,_RL54S03SBRN,_1SM,_1RM,
    _1NES,_1PRK,_1S0);
  _RL54S03SM = _1SM;
  _RL54S03PRM = _1RM;
  _RL54S03NES = _1NES;
  _RL54_SR->_SR(_RL54S03RPU,_RL54S03USTVU,_RL54S03D,0,0,_D14MC4_84D,false,false,_RL54S03KOSR,0,0,_RL54S03ZNK,
    _RL54S03TKU,_RL54S03VPR,_RL54S03DHN,_RL54S03RNR,false,true,_RL54S03ZN,_RL54S03ZV,_RL54S03EMN,_RL54S03KP,
    _RL54S03TI1,_RL54S03TI2,false,false,_RL54S03OTK,_RL54S03ZAK,_RL54S03ZNZ,_RL54S03ZVZ,_RL54S03NLO,_RL54S03NLZ,
    _RL54S03VKOR,_RL54S03KM,_RL54S03DK,0,_RL54S03SM,_RL54S03PRM,_1S0,_0XOS,_0XPR,_0CI,_0ERZ,_0OTKR,_0ZAKR,_0DHNO,
    _0ER);
  _RL54S03XOS = _0XOS;
  _RL54S03XPR = _0XPR;
  _RL54S03CI = _0CI;
  _RL54S03ERZ = _0ERZ;
  _RL54S03A03REG = _0OTKR;
  _RL54S03DHN = _0DHNO;
  _2_R = _RL54S03BLPR || _0ZAKR;
  _RL54S03A04REG = _2_R;
}

void _RL54C03()
{

  _LVR_LFU_RL54();
  _BLOK_RL54();
  _ZR_RL54();
}

void _OCHK()
{
  smallint _0KUIO = 0;
  smallint _0INHOIR = 0;
  bool _0BCHV = false;
  smallint _1KUIO = 0;
  smallint _1INHOIR = 0;
  bool _1BCHV = false;
  smallint _2KUIO = 0;
  smallint _2INHOIR = 0;
  bool _2BCHV = false;
  smallint _3KUIO = 0;
  smallint _3INHOIR = 0;
  bool _3BCHV = false;
  smallint _4KUIO = 0;
  smallint _4INHOIR = 0;
  bool _4BCHV = false;
  smallint _5KUIO = 0;
  smallint _5INHOIR = 0;
  bool _5BCHV = false;
  smallint _6KUIO = 0;
  smallint _6INHOIR = 0;
  bool _6BCHV = false;

  _TK11J02_OCHK->_OCHK(_TK11J02AVT,_TK11J02A03REG,_TK11J02A04REG,_0KUIO,_0INHOIR,_0BCHV);
  _TK11J02KUIO = _0KUIO;
  _TK11J02HOUR = _0INHOIR;
  _TK11J02BVCH = _0BCHV;
  _RL53S03_OCHK->_OCHK(_RL53S03AVT,_RL53S03A03REG,_RL53S03A04REG,_1KUIO,_1INHOIR,_1BCHV);
  _RL53S03KUIO = _1KUIO;
  _RL53S03HOUR = _1INHOIR;
  _RL53S03BCHV = _1BCHV;
  _RL54S03_OCHK->_OCHK(_RL54S03AVT,_RL54S03A03REG,_RL54S03A04REG,_2KUIO,_2INHOIR,_2BCHV);
  _RL54S03KUIO = _2KUIO;
  _RL54S03HOUR = _2INHOIR;
  _RL54S03BCHV = _2BCHV;
  _RA13S04_OCHK->_OCHK(_RA13S04AVT,_RA13S04A03REG,_RA13S04A04REG,_3KUIO,_3INHOIR,_3BCHV);
  _RA13S04KUIO = _3KUIO;
  _RA13S04HOUR = _3INHOIR;
  _RA13S04BCHV = _3BCHV;
  _RA14S04_OCHK->_OCHK(_RA14S04AVT,_RA14S04A03REG,_RA14S04A04REG,_4KUIO,_4INHOIR,_4BCHV);
  _RA14S04KUIO = _4KUIO;
  _RA14S04HOUR = _4INHOIR;
  _RA14S04BCHV = _4BCHV;
  _TH11S15_OCHK->_OCHK(_TH11S15AVT,_TH11S15A03REG,_TH11S15A04REG,_5KUIO,_5INHOIR,_5BCHV);
  _TH11S15KUIO = _5KUIO;
  _TH11S15HOUR = _5INHOIR;
  _TH11S15BCHV = _5BCHV;
  _TH11S18_OCHK->_OCHK(_TH11S18AVT,_TH11S18A03REG,_TH11S18A04REG,_6KUIO,_6INHOIR,_6BCHV);
  _TH11S18KUIO = _6KUIO;
  _TH11S18HOUR = _6INHOIR;
  _TH11S18BCHV = _6BCHV;
}

void _MNMRO()
{
  smallint _0LBDMRO = 0;
  smallint _1LBDMRO = 0;
  smallint _2LBDMRO = 0;
  bool _8_R = false;
  smallint _3LBDMRO = 0;
  bool _9_R = false;
  smallint _4LBDMRO = 0;
  smallint _5LBDMRO = 0;
  smallint _6LBDMRO = 0;
  smallint _7LBDMRO = 0;

  _0LBDMRO = _TK11J02_MRO->_MNMR0(false,false,false,false,false,false,_TK11J02A03REG,_TK11J02A04REG,false,
    false,false,false,_TK11J02REM,_TK11J02AVT,false,_TK11J02ZS);
  _TK11J02MRO = _0LBDMRO;
  _1LBDMRO = _RL53S03_MRO->_MNMR0(false,false,false,false,false,false,_RL53S03A03REG,_RL53S03A04REG,false,
    false,false,false,_RL53S03REM,_RL53S03AVT,false,_RL53S03ZS);
  _RL53S03MRO = _1LBDMRO;
  _2LBDMRO = _RL54S03_MRO->_MNMR0(false,false,false,false,false,false,_RL54S03A03REG,_RL54S03A04REG,false,
    false,false,false,_RL54S03REM,_RL54S03AVT,false,_RL54S03ZS);
  _RL54S03MRO = _2LBDMRO;
  _8_R = _RA13PB74ZBO || _RA13_PROTK;
  _3LBDMRO = _RA13S04_MRO->_MNMR0(_8_R,_RA13PM67ZBZ,false,false,false,false,_RA13S04A03REG,_RA13S04A04REG,
    false,false,false,false,_RA13S04REM,_RA13S04AVT,false,_RA13S04ZS);
  _RA13S04MRO = _3LBDMRO;
  _9_R = _RA14PB74ZBO || _RA14_PROTK;
  _4LBDMRO = _RA14S04_MRO->_MNMR0(_9_R,_RA14PM67ZBZ,false,false,false,false,_RA14S04A03REG,_RA14S04A04REG,
    false,false,false,false,_RA14S04REM,_RA14S04AVT,false,_RA14S04ZS);
  _RA14S04MRO = _4LBDMRO;
  _5LBDMRO = _TH11S15_MRO->_MNMR0(false,false,false,false,false,false,_TH11S15A03REG,_TH11S15A04REG,false,
    false,false,false,_TH11S15REM,_TH11S15AVT,false,_TH11S15ZS);
  _TH11S15MRO = _5LBDMRO;
  _6LBDMRO = _REZERV_MRO->_MNMR0(false,false,false,false,false,false,false,false,false,false,false,false,
    false,false,false,false);
  _REZERVMRO = _6LBDMRO;
  _7LBDMRO = _TH11S18_MRO->_MNMR0(false,false,false,false,false,false,_TH11S18A03REG,_TH11S18A04REG,false,
    false,false,false,_TH11S18REM,_TH11S18AVT,false,_TH11S18ZS);
  _TH11S18MRO = _7LBDMRO;
}

void _VIZOV()
{
  bool _0_R = false;

  _0_R = _NEISPR_0 || _SHU5APN;
  _SHU5SSR = _0_R;
}

void _shu335()
{
  smallint _0_R = 0;
  smallint _1_R = 0;

  _MNMRI();
  _KPIM();
  _FILTR();
  _KD();
  _TH11C15_C18();
  _TK11J02REG();
  _RA13C04();
  _RA14C04();
  _RL53C03();
  _RL54C03();
  _OCHK();
  _MNMRO();
  _VIZOV();
  _0_R = _TH11S15;
  _TH11S15O1 = _0_R;
  _TH11S15O = _0_R;
  _1_R = _TH11S18;
  _TH11S18O1 = _1_R;
  _TH11S18O = _1_R;
}

