#include "tasks.h"
#include "shu335.h"

void _TaskFPO()
{
  _shu335();
}

