#ifndef modelH
#define modelH
#include "usertype.h"
#include "uIncludes.h"

void _TH13S15_M();
void _TH13S18_M();
void _TK13J02_M();
void _RA12S04_M();
void _RL52S03_M();
void _TP60S05_M();
void _model();

#endif
