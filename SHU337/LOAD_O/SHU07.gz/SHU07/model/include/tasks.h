#ifndef tasksH
#define tasksH

void _TaskMod();

#endif
