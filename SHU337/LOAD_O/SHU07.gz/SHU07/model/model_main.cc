

         







#include "SigChangeM.h"
#include "model.h"
#include "cdsface.h"
#include "cdshead.h"
#include "cdsinch.h"
#include <stdio.h>
#include "uobjects.h"
#include "globals.h"
#include "tasks.h"

main(int argc, char*argv[])
{
  void * start, *finish;
  int i, res;
  start  =(void*)&cds::startSession;//NP
  finish =(void*)&cds::stopSession;//NP 
  Init_PM();
/*  Init_modelPasp();
  Init_model();
*/  
  InitObjects();
 // InitPulse();
 // Init_VH();  
  
  CDS_OCCUP = false;//NP 
  res = cdsinch_init(argc,argv, &start, &finish);
  for (;;) 
  {
	res = cdsinch_begin(start); 
	    Read_SigM();
       _TaskMod();
        Write_SigM();
             
	res = cdsinch_end(finish);
  }
}; 


