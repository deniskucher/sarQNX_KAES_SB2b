#include "tasks.h"
#include "shu337.h"

void _TaskFPO()
{
  _shu337();
}

