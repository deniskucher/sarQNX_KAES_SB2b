#ifndef shu327H
#define shu327H
#include "usertype.h"
#include "uIncludes.h"

void _MNMRI();
void _KPIM();
void _FILTR();
void _LVR_LFU_TH13();
void _POSLED_UPR();
void _ZR_TH13();
void _TH13S15_S18();
void _LVR_LFU_TK13();
void _VR_TK13J02();
void _ZR_TK13J02();
void _TK13J02REG();
void _LVR_LFU_RA12();
void _BLOK_RA12();
smallint _Multiple(const smallint IN1, const smallint IN2);
void _ZR_RA12S04();
void _RA12C04();
void _LVR_LFU_RL52();
void _BLOK_RL52();
void _ZR_RL52S03();
void _RL52C03();
void _OCHK();
void _MNMRO();
void _VIZOV();
void _shu327();

#endif
