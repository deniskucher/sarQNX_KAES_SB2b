#ifndef KDH
#define KDH
#include "KD_Classes.h"
  extern bool _TH13S15F_1; // to reserve MK
  extern bool _TH13S18F_1; // to reserve MK
  extern bool _TK13J02F_1; // to reserve MK
  extern bool _RA12S04F_1; // to reserve MK
  extern bool _RL52S03F_1; // to reserve MK
  extern bool _Y067B20F_1; // to reserve MK
  extern bool _T073B03F_1; // to reserve MK
  extern bool _T118B03F_1; // to reserve MK
  extern bool _T118B02F_1; // to reserve MK
  extern bool _D14MC2_79F_1; // to reserve MK
  extern bool _D14MC2_86F_1; // to reserve MK
  extern bool _YA12T767F_1; // to reserve MK
  extern bool _TH13T151F_1; // to reserve MK
  extern bool _TP60S05F_1; // to reserve MK
  extern bool _YA12T779F_1; // to reserve MK
  extern bool _T651P01F_1; // to reserve MK
  const short KOL_AI1=16;
  const short KOL_AI2=(2/2);
  const short KOL_AI3=(0/3);
  extern void KD_RUN(); 
  extern void Init_KD();
#endif
