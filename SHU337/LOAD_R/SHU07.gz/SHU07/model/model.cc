#include "uobjects.h"
#include "globals.h"
#include "model.h"

void _TH13S15_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TH13S15M_MRI->_MR_MRI(_TH13S15MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,
    _2VH4,_2REM,_2AVT,_2ZVK,_2ZS);
  _TH13S15_MR->_MR_009(_TH13S15B02,_TH13S15B01,_TH13S15SA2,_TH13S15SA1,false,false,_TH13S15SAC,_TH13S15SAD,
    _TH13S15SA1R,_TH13S15SA2R,_TH13S15RHU,_TH13S15BHU,_TH13S15SA3,_TH13S15SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TH13S15M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TH13S15MRI = _0LBDMRO;
}

void _TH13S18_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TH13S18M_MRI->_MR_MRI(_TH13S18MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,
    _2VH4,_2REM,_2AVT,_2ZVK,_2ZS);
  _TH13S18_MR->_MR_009(_TH13S18B02,_TH13S18B01,_TH13S18SA2,_TH13S18SA1,false,false,_TH13S18SAC,_TH13S18SAD,
    _TH13S18SA1R,_TH13S18SA2R,_TH13S18RHU,_TH13S18BHU,_TH13S18SA3,_TH13S18SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TH13S18M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TH13S18MRI = _0LBDMRO;
}

void _TK13J02_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TK13M_MRI->_MR_MRI(_TK13J02MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TK13_MR->_MR_009(_TK13J02B02,_TK13J02B01,_TK13J02SA2,_TK13J02SA1,false,false,_TK13J02SAC,_TK13J02SAD,
    _TK13J02SA1R,_TK13J02SA2R,_TK13J02RHU,_TK13J02BHU,_TK13J02SA3,_TK13J02SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TK13M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TK13J02MRI = _0LBDMRO;
}

void _RA12S04_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _RA12M_MRI->_MR_MRI(_RA12S04MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _RA12_MR->_MR_009(_RA12S04B02,_RA12S04B01,_RA12S04SA2,_RA12S04SA1,false,false,_RA12S04SAC,_RA12S04SAD,
    _RA12S04SA1R,_RA12S04SA2R,_RA12S04RHU,_RA12S04BHU,_RA12S04SA3,_RA12S04SA4,_RA12S04KBR,_RA12S04B06,_2ZBPR,
    _2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,true,false,33,21,_1A03,_1A04,_1TZOVU,
    _1TZZVU,_1SA1VU,_1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _RA12M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _RA12S04MRI = _0LBDMRO;
}

void _RL52S03_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _RL52M_MRI->_MR_MRI(_RL52S03MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _RL52_MR->_MR_009(_RL52S03B02,_RL52S03B01,_RL52S03SA2,_RL52S03SA1,false,false,_RL52S03SAC,_RL52S03SAD,
    _RL52S03SA1R,_RL52S03SA2R,_RL52S03RHU,_RL52S03BHU,_RL52S03SA3,_RL52S03SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,false,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _RL52M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _RL52S03MRI = _0LBDMRO;
}

void _TP60S05_M()
{
  bool _2ZBPR = false;
  bool _2ZBUB = false;
  bool _2ZO = false;
  bool _2ZZ = false;
  bool _2BPR = false;
  bool _2BUB = false;
  bool _2LOGPR = false;
  bool _2LOGUB = false;
  bool _2VH1 = false;
  bool _2VH2 = false;
  bool _2VH3 = false;
  bool _2VH4 = false;
  bool _2REM = false;
  bool _2AVT = false;
  bool _2ZVK = false;
  bool _2ZS = false;
  bool _1A03 = false;
  bool _1A04 = false;
  bool _1TZOVU = false;
  bool _1TZZVU = false;
  bool _1SA1VU = false;
  bool _1SA2VU = false;
  bool _1SG = false;
  bool _1REZ1D = false;
  bool _1REZ2D = false;
  bool _1REZ3D = false;
  bool _1REZ4D = false;
  smallint _0LBDMRO = 0;

  _TP60M_MRI->_MR_MRI(_TP60S05MRO,_2ZBPR,_2ZBUB,_2ZO,_2ZZ,_2BPR,_2BUB,_2LOGPR,_2LOGUB,_2VH1,_2VH2,_2VH3,_2VH4,
    _2REM,_2AVT,_2ZVK,_2ZS);
  _TP60_MR->_MR_009(_TP60S05B02,_TP60S05B01,_TP60S05SA2,_TP60S05SA1,false,false,_TP60S05SAC,_TP60S05SAD,
    _TP60S05SA1R,_TP60S05SA2R,_TP60S05RHU,_TP60S05BHU,_TP60S05SA3,_TP60S05SA4,false,false,false,false,false,false,
    false,false,_2LOGPR,_2LOGUB,_2REM,_2AVT,true,true,true,false,false,0,0,_1A03,_1A04,_1TZOVU,_1TZZVU,_1SA1VU,
    _1SA2VU,_1SG,_1REZ1D,_1REZ2D,_1REZ3D,_1REZ4D);
  _0LBDMRO = _TP60M_MRO->_MR_MRO(false,false,_1A03,_1A04,false,false,_1SA1VU,_1SA2VU,false,_1REZ1D,_1REZ2D,
    _1REZ3D,_1REZ4D,false,false,false);
  _TP60S05MRI = _0LBDMRO;
}

void _model()
{

  _TH13S15_M();
  _TH13S18_M();
  _TK13J02_M();
  _RA12S04_M();
  _RL52S03_M();
  _TP60S05_M();
}

